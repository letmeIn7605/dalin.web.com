from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/projects')
def projects():
    project_list = [
        {'name': 'Project 1', 'description': 'Description of project 1'},
        {'name': 'Project 2', 'description': 'Description of project 2'},
        {'name': 'Project 3', 'description': 'Description of project 3'}
    ]
    return render_template('projects.html', projects=project_list)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

